package com.vivitasol.projectbackend.repositories;

import org.springframework.data.repository.CrudRepository;

import com.vivitasol.projectbackend.entities.Producto;

public interface  ProductoRepositories extends CrudRepository <Producto, Long>{

}
