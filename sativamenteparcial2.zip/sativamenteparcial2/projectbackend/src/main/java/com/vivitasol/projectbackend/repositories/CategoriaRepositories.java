package com.vivitasol.projectbackend.repositories;

import org.springframework.data.repository.CrudRepository;

import com.vivitasol.projectbackend.entities.Categoria;

public interface CategoriaRepositories extends CrudRepository<Categoria, Long> {

}
